document.addEventListener('DOMContentLoaded', () => {
    // Asegura que todo el HTML se haya cargado antes de intentar manipular los elementos.

    // ------------------ 1. REFERENCIAS DE ELEMENTOS HTML ------------------
    // Se declaran constantes para almacenar referencias a los elementos del DOM (Document Object Model) 
    // usando sus IDs. Esto se hace una sola vez para mejorar el rendimiento.
    const chatToggleButton = document.getElementById('chatToggleButton'); // Botón de Elia para abrir el chat.
    const closeChatButton = document.getElementById('closeChatButton');   // Botón 'x' para cerrar el chat.
    const refreshButton = document.getElementById('refreshButton');       // Botón de recarga para reiniciar el chat.
    const chatWindow = document.getElementById('chatWindow');             // Contenedor principal de la ventana de Bina.
    const chatBody = document.getElementById('chatBody');                 // Contenedor principal donde se muestran los mensajes.
    const messageInput = document.getElementById('messageInput');         // Campo de texto para escribir mensajes.
    const sendButton = document.getElementById('sendButton');             // Botón de enviar mensaje.

    // ------------------ 2. ESTRUCTURAS DE MENSAJES (CONTENIDO) ------------------

    // Array que contiene el HTML de los mensajes iniciales y los botones de opción.
    const initialMessages = [
        // Mensaje de bienvenida 1
        '<div class="message-bubble assistant"><p>¡Hola! Soy Bina, el asistente virtual de Indra. Puedes preguntarme dudas o enviar peticiones a Service Point sobre los ámbitos que domino.</p></div>',
        // Mensaje de estado/advertencia 
        '<div class="message-bubble assistant"><p>Actualmente, algunas de mis funciones pueden no estar disponibles. Si durante nuestra conversación detectas algún problema o error, por favor, no dudes en enviar una petición a través de Service Point para informarlo.</p></div>',

        // BLOQUE COMBINADO: Contiene el mensaje de texto final Y los botones de opción.
        // Se usa un template literal (backticks ``) para incluir saltos de línea y facilitar la lectura del HTML.
        `<div class="message-bubble assistant">
            <p>Estos son los temas en los que te puedo atender actualmente, puedes orientarte a través de los botones o escribirme directamente tus dudas:</p>
            <div class="action-buttons-container" id="optionButtons">
                <button class="action-option-button" data-topic="dispositivos">Dispositivos y telefonía</button>
                <button class="action-option-button" data-topic="formacion">Formación</button>
                <button class="action-option-button" data-topic="permisos">Permisos retribuidos</button>
                <button class="action-option-button" data-topic="gastos">Gastos de empleado</button>
            </div>
        </div>`
    ];

    // Función que genera dinámicamente la secuencia de respuesta de Bina para cualquier tema.
    const createResponse = (topicName, shortMessage) => {
        return [
            // 1. Burbuja de usuario simulando el clic (se inyecta en handleOptionClick, pero se incluye aquí para la secuencia lógica)
            `<div class="user-action-float selected-option"><button class="user-float-button">${topicName}</button></div>`,

            // 2. Muestra los botones iniciales, pero con la clase 'clicked' para que se vean deshabilitados.
            `<div class="action-buttons-container" id="optionButtons" style="margin-top: 15px;">
                <button class="action-option-button clicked" data-topic="dispositivos">Dispositivos y telefonía</button>
                <button class="action-option-button clicked" data-topic="formacion">Formación</button>
                <button class="action-option-button clicked" data-topic="permisos">Permisos retribuidos</button>
                <button class="action-option-button clicked" data-topic="gastos">Gastos de empleado</button>
            </div>`,

            // 3. Respuesta de Bina específica (mensaje introductorio)
            `<div class="message-bubble assistant response-start"><p>${shortMessage}</p></div>`,
            // 4. Mensaje de orientación al Service Point
            '<div class="message-bubble assistant"><p>Puedes consultar más información a través de <strong>Service point</strong>, mediante el buscador o abriendo una consulta. También puedes abrir la consulta directamente desde aquí.</p></div>',
            // 5. Opción de continuar o reiniciar
            '<div class="message-bubble assistant"><p>Si quieres hablar de otro tema, puedes preguntarme directamente o reiniciar el chat.</p></div>',

            // 6. Botón de acción para Service Point
            `<div class="user-action-float"><button class="user-float-button">Enviar una petición sobre ${topicName.toLowerCase()} a Service point</button></div>`,
            // 7. Solicitud de resumen (paso final del flujo simulado)
            `<div class="message-bubble assistant"><p>Escribe un resumen de tu petición sobre tu ${topicName.toLowerCase()}. Si quieres cancelar o modificar la operación, podrás hacerlo tras completar el formulario.</p></div>`
        ];
    };

    // Objeto que mapea las claves de los botones (data-topic) a sus secuencias de respuesta generadas.
    const responses = {
        formacion: createResponse("Formación", "En estos momentos estoy actualizando mis conocimientos sobre formación para adecuarlos a la nueva plataforma Open University."),
        dispositivos: createResponse("Dispositivos y telefonía", "El área de Dispositivos y telefonía se encarga de dar soporte a todo el hardware que usas en tu día a día, incluyendo móviles, portátiles y accesorios."),
        permisos: createResponse("Permisos retribuidos", "El tema de Permisos retribuidos abarca consultas sobre vacaciones, días libres, licencias por matrimonio, paternidad y otras ausencias legales."),
        gastos: createResponse("Gastos de empleado", "En este tema te puedo ayudar con dudas sobre el proceso de reporte de gastos, reportes de viaje y solicitudes de tickets y justificantes.")
    };


    // ------------------ 3. FUNCIONES DE LÓGICA DE CHAT ------------------

    // Función para forzar el scroll al final del chat.
    function scrollToBottom() {
        chatBody.scrollTop = chatBody.scrollHeight; // Establece la posición del scroll al final del contenido.
    }

    // Función que inicializa el chat: carga mensajes de bienvenida y botones.
    function loadInitialChat() {
        // Inyecta todo el HTML de 'initialMessages' en el cuerpo del chat.
        chatBody.innerHTML = initialMessages.join(''); // '.join('')' convierte el array de strings en un único string de HTML.
        scrollToBottom(); // Desplaza al final para ver los últimos mensajes/botones.

        // Adjunta los listeners de eventos a los botones recién creados (necesario ya que se inyectan dinámicamente)
        const buttons = chatBody.querySelectorAll('.action-option-button'); // Selecciona todos los botones de opción.
        buttons.forEach(button => {
            button.addEventListener('click', handleOptionClick); // Asigna la función de manejo de clic.
        });
    }

    // Función que se ejecuta cuando el usuario hace clic en uno de los 4 botones de opción.
    function handleOptionClick(event) {
        const button = event.target;
        const topic = button.getAttribute('data-topic'); // Obtiene el tema (ej: 'formacion') del atributo data-topic.
        const topicName = button.textContent;           // Obtiene el texto visible del botón (ej: 'Formación').

        // Desactivar todos los botones de opción (para evitar múltiples clics)
        const allButtons = document.querySelectorAll('#optionButtons .action-option-button');
        allButtons.forEach(btn => {
            btn.classList.add('clicked');              // Aplica estilo CSS de botón deshabilitado.
            btn.removeEventListener('click', handleOptionClick); // Elimina el listener de clic.
        });

        // 1. Inyectar la burbuja de usuario simulando el clic
        chatBody.innerHTML += `<div class="user-action-float selected-option"><button class="user-float-button">${topicName}</button></div>`;

        // 2. Simular respuesta
        if (responses[topic]) {
            // Eliminar el contenedor de botones ya clickeado
            // document.getElementById('optionButtons').remove(); // Se asume que esto se hace automáticamente al inyectar el nuevo contenido.
            // NOTA: Para este flujo, se debe eliminar el contenedor original o inyectar el nuevo contenido después.

            // Inyecta la secuencia de respuesta, omitiendo la primera burbuja que ya se inyectó.
            const content = responses[topic].slice(1).join('');
            chatBody.innerHTML += content;

        } else {
            // Caso de tema no manejado
            chatBody.innerHTML += '<div class="message-bubble assistant"><p>Lo siento, aún estoy aprendiendo sobre este tema. Por favor, reinicia el chat.</p></div>';
        }

        // Si se mantiene la función de scroll, debe ir aquí para ver la respuesta completa.
        scrollToBottom();
    }

    // FUNCIÓN PARA MANEJAR EL ENVÍO DE TEXTO DEL USUARIO
    function handleSend() {
        const message = messageInput.value.trim(); // Obtiene el valor y elimina espacios al inicio/final.

        if (message !== "") {
            // 1. Inyectar el mensaje del usuario
            const userMessageHTML = `<div class="message-bubble user-message" style="background-color:#0076a3; color:white; margin-left:auto; text-align:right; border-radius:8px 8px 0 8px;">${message}</div>`;
            chatBody.innerHTML += userMessageHTML;

            // 2. Limpiar el campo de entrada
            messageInput.value = '';

            // Se deja comentado el scroll para dar control al usuario, pero se puede activar si se requiere scroll automático.
            // scrollToBottom(); 
        }
    }

    // Función para mostrar u ocultar la ventana del chat.
    function toggleChat() {
        if (chatWindow.style.display === 'block') {
            // Si está visible, la oculta y muestra el botón de Elia.
            chatWindow.style.display = 'none';
            chatToggleButton.style.display = 'flex';
        } else {
            // Si está oculta, la muestra y oculta el botón de Elia.
            chatWindow.style.display = 'block';
            chatToggleButton.style.display = 'none';
            loadInitialChat(); // Carga los mensajes de bienvenida y los botones.
        }
    }

    // ------------------ 4. EVENT LISTENERS ------------------
    // Asigna la función 'toggleChat' al hacer clic en los botones de abrir y cerrar.
    chatToggleButton.addEventListener('click', toggleChat);
    closeChatButton.addEventListener('click', toggleChat);

    // Asigna la función 'loadInitialChat' para reiniciar la conversación.
    refreshButton.addEventListener('click', loadInitialChat);

    // Maneja el envío de texto con el botón de flecha.
    sendButton.addEventListener('click', handleSend);

    // Maneja el envío de texto al presionar la tecla Enter en el campo de entrada.
    messageInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            handleSend();
        }
    });
});