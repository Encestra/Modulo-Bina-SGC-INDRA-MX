<?php
header('Content-Type: application/json; charset=utf-8');

// 1. Conexión a la base de datos
$host = 'localhost';
$db = 'ia';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (PDOException $e) {
    echo json_encode(['reply' => 'Error de conexión: ' . $e->getMessage()]);
    exit;
}

// Detecta intención de ayuda/capacidades
function detectarIntentAyuda($texto) {
    $s = is_array($texto) ? implode(' ', $texto) : $texto;
    // claves comunes
    $patrones = [
        '/en\s+que\s+puedes\s+ayudar/',
        '/como\s+me\s+puedes\s+ayudar/',
        '/que\s+puedes\s+hacer/',
        '/ayuda/',
        '/help/'
    ];
    foreach ($patrones as $p) {
        if (preg_match($p, $s)) return true;
    }
    return false;
}

// Detecta si el usuario pide un listado general de una entidad
// Devuelve uno de: manual, preguntas_frec, empleados, area, nivel, localizacion, tipo_trab, o null
function detectarListadoEntidad($textoTokens, $userRawLower) {
    $s = is_array($textoTokens) ? implode(' ', $textoTokens) : $textoTokens;
    // señales de listado
    $hayListado = (bool)preg_match('/\blista|listar|muestrame|muestra|cuales\s+son|que\s+tienes|que\s+hay|dime\s+todos|ver\s+todos/', $s);
    // detectar por entidad
    $m = null;
    if (preg_match('/manual|manuales|guia|guias|instructivo|documentacion/', $s)) $m = 'manual';
    if (preg_match('/faq|preguntas|frecuentes/', $s)) $m = $m ?: 'preguntas_frec';
    if (preg_match('/empleado|empleados|trabajador|trabajadores|personal|gente|nomina|staff/', $s)) $m = $m ?: 'empleados';
    if (preg_match('/area|areas/', $s)) $m = $m ?: 'area';
    if (preg_match('/nivel|niveles/', $s)) $m = $m ?: 'nivel';
    if (preg_match('/localizacion|localizaciones|ubicacion|ubicaciones/', $s)) $m = $m ?: 'localizacion';
    if (preg_match('/tipo\s*de\s*trabajo|tipos\s*de\s*trabajo|tipo_trab|modalidad/', $s)) $m = $m ?: 'tipo_trab';

    // Si menciona la entidad aunque no diga "lista", asumir listado
    if ($m) return $m;
    // Si expresó palabras de listado pero no entidad, intenta con intención AI
    if ($hayListado) return 'empleados';
    return null;
}

// Construye listados desde BD según entidad
function construirListadoDesdeBD($pdo, $entidad) {
    try {
        switch ($entidad) {
            case 'manual':
                $stmt = $pdo->query("SELECT palabra_clave, recomendacion FROM manual LIMIT 50");
                $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
                if (!$rows) return null;
                $out = '<strong>Manuales disponibles:</strong><br><br>';
                foreach ($rows as $r) {
                    $pk = htmlspecialchars($r['palabra_clave'] ?? '');
                    $rec = convertirLinksEnHtml($r['recomendacion'] ?? '');
                    $out .= "- <strong>$pk</strong>: $rec<br><br>";
                }
                return $out;
            case 'preguntas_frec':
                $stmt = $pdo->query("SELECT palabra_clave, recomendacion FROM preguntas_frec LIMIT 50");
                $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
                if (!$rows) return null;
                $out = '<strong>Preguntas frecuentes:</strong><br><br>';
                foreach ($rows as $r) {
                    $pk = htmlspecialchars($r['palabra_clave'] ?? '');
                    $rec = convertirLinksEnHtml($r['recomendacion'] ?? '');
                    $out .= "- <strong>$pk</strong>: $rec<br><br>";
                }
                return $out;
            case 'empleados':
                $stmt = $pdo->query("SELECT e.nombre, e.apellido, a.descripcion AS area FROM empleado e LEFT JOIN area a ON e.id_area = a.id_area LIMIT 20");
                $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
                if (!$rows) return null;
                $out = '<strong>Algunos empleados:</strong><br><br>';
                foreach ($rows as $r) {
                    $out .= '- <strong>' . htmlspecialchars($r['nombre']) . ' ' . htmlspecialchars($r['apellido']) . '</strong>' . ' | Área: ' . htmlspecialchars($r['area'] ?? '') . '<br><br>';
                }
                $out .= '<em>Mostrando un máximo de 20 resultados.</em>';
                return $out;
            case 'area':
                $stmt = $pdo->query("SELECT descripcion FROM area ORDER BY descripcion");
                $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
                if (!$rows) return null;
                $out = '<strong>Áreas registradas:</strong><br><br>';
                foreach ($rows as $r) { $out .= '- ' . htmlspecialchars($r['descripcion']) . '<br>'; }
                return $out;
            case 'nivel':
                $stmt = $pdo->query("SELECT descripcion FROM nivel ORDER BY descripcion");
                $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
                if (!$rows) return null;
                $out = '<strong>Niveles registrados:</strong><br><br>';
                foreach ($rows as $r) { $out .= '- ' . htmlspecialchars($r['descripcion']) . '<br>'; }
                return $out;
            case 'localizacion':
                $stmt = $pdo->query("SELECT descripcion FROM localizacion ORDER BY descripcion");
                $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
                if (!$rows) return null;
                $out = '<strong>Localizaciones registradas:</strong><br><br>';
                foreach ($rows as $r) { $out .= '- ' . htmlspecialchars($r['descripcion']) . '<br>'; }
                return $out;
            case 'tipo_trab':
                $stmt = $pdo->query("SELECT descripcion FROM tipo_trab ORDER BY descripcion");
                $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
                if (!$rows) return null;
                $out = '<strong>Tipos de trabajo registrados:</strong><br><br>';
                foreach ($rows as $r) { $out .= '- ' . htmlspecialchars($r['descripcion']) . '<br>'; }
                return $out;
        }
    } catch (Exception $ex) {
        return null;
    }
    return null;
}

function convertirLinksEnHtml($texto) {
    return preg_replace(
        '/(https?:\/\/[^\s]+)/',
        '<a href="$1" target="_blank">$1</a>',
        $texto
    );
}

// Asegura que el texto sea UTF-8 válido para json_encode
function asegurarUtf8($texto) {
    if ($texto === null) return '';
    // Si mb_detect_encoding no está, intentar utf8_encode como fallback
    if (function_exists('mb_detect_encoding')) {
        if (!mb_detect_encoding($texto, 'UTF-8', true)) {
            if (function_exists('mb_convert_encoding')) {
                return mb_convert_encoding($texto, 'UTF-8', 'auto');
            }
            return utf8_encode($texto);
        }
        return $texto;
    }
    // Sin mbstring
    return utf8_encode($texto);
}

// Normaliza texto en español: minúsculas, quita acentos y stopwords simples
function normalizarTexto($texto) {
    // a) to lower robusto
    if (function_exists('mb_strtolower')) {
        $t = mb_strtolower(trim($texto), 'UTF-8');
    } else {
        $t = strtolower(trim($texto));
    }
    // b) quitar acentos si iconv disponible
    if (function_exists('iconv')) {
        $converted = @iconv('UTF-8', 'ASCII//TRANSLIT', $t);
        if ($converted !== false && $converted !== null) {
            $t = $converted;
        }
    }
    // c) limpiar no alfanumérico y espacios
    $t = preg_replace('/[^a-z0-9\s]/', ' ', $t);
    $t = preg_replace('/\s+/', ' ', $t);
    // Stopwords muy básicas orientadas a preguntas
    $stop = [
        'de','la','el','los','las','un','una','unos','unas','lo','al','del',
        'que','cual','cuales','cuáles','cuales','cual','son','es','por','para',
        'quien','quienes','quién','quiénes','dime','di','muestrame','muestráme',
        'muestra','mostrar','ver','lista','listar','enseñame','ensename','me',
        'los','las','a','en','con','sobre','de','un','una','como','cómo','cuanto','cuánto'
    ];
    $tokens = array_values(array_filter(explode(' ', $t), function($w) use ($stop) {
        return $w !== '' && !in_array($w, $stop, true);
    }));
    return $tokens;
}

// Detecta intent de empleados por sinónimos comunes
function detectarIntentEmpleados($textoNormalizadoSinAcentos) {
    // Trabajamos sobre el string completo para facilitar coincidencias
    $s = is_array($textoNormalizadoSinAcentos)
        ? implode(' ', $textoNormalizadoSinAcentos)
        : $textoNormalizadoSinAcentos;
    $sinonimos = [
        'empleado','empleados','trabajador','trabajadores','personal','gente','nomina','nómina','staff'
    ];
    foreach ($sinonimos as $pal) {
        if (strpos($s, $pal) !== false) return true;
    }
    // Patrones tipo "quien es" implican entidad persona
    if (preg_match('/\bquien\s+es\b/', $s)) {
        return true;
    }
    return false;
}

// 2. Obtener el mensaje del usuario
$userMessage = strtolower(trim($_POST['mensaje'] ?? ''));
$tokensNorm = normalizarTexto($userMessage);
$intentaEmpleados = detectarIntentEmpleados($tokensNorm);

// 2.1. Integración con OpenAI (intents y entidad)
require_once __DIR__ . '/ai_client.php';
$aiIntent = null;
$aiEntity = '';
$aiClassification = ai_classify_intent($userMessage);
if (is_array($aiClassification)) {
    $aiIntent = $aiClassification['intent'] ?? null;
    $aiEntity = $aiClassification['entity'] ?? '';
    if ($aiIntent === 'empleados') {
        $intentaEmpleados = true; // refuerza el intent detectado manualmente
    }
}

// 3. Buscar coincidencias en preguntas frecuentes y manual (ahora con SQL LIKE)
function buscarEnTablaPalabrasClave($pdo, $tabla, $mensaje) {
    try {
        // Busca tanto en palabra_clave como en recomendacion
        $stmt = $pdo->prepare("SELECT recomendacion FROM $tabla WHERE LOWER(palabra_clave) LIKE ? OR LOWER(recomendacion) LIKE ? LIMIT 1");
        $stmt->execute(["%$mensaje%", "%$mensaje%"]);
        $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
        return $resultado['recomendacion'] ?? null;
    } catch (Exception $e) {
        return null;
    }
}

// Búsqueda semántica simple usando IA para expandir palabras clave
function buscarEnTablaSemantico($pdo, $tabla, $mensaje) {
    // Primero, intento directo (por compatibilidad)
    $directa = buscarEnTablaPalabrasClave($pdo, $tabla, $mensaje);
    if ($directa) return $directa;

    // Luego, si hay IA configurada, expandimos palabras clave
    if (function_exists('ai_expand_keywords')) {
        $keywords = ai_expand_keywords($mensaje);
        if (is_array($keywords) && !empty($keywords)) {
            // Construir consulta dinámica con ORs sobre palabra_clave y recomendacion
            $likes = [];
            $params = [];
            foreach ($keywords as $kw) {
                $likes[] = "(LOWER(palabra_clave) LIKE ? OR LOWER(recomendacion) LIKE ?)";
                $params[] = "%$kw%";
                $params[] = "%$kw%";
            }
            try {
                $sql = "SELECT recomendacion FROM $tabla WHERE " . implode(' OR ', $likes) . " LIMIT 1";
                $stmt = $pdo->prepare($sql);
                $stmt->execute($params);
                $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
                return $resultado['recomendacion'] ?? null;
            } catch (Exception $e) {
                // Ignorar y continuar con expansión local
            }
        }
    }
    
    // Sin IA: expansión local de palabras clave a partir de heurísticas
    $tokens = normalizarTexto($mensaje);
    $extra = [];
    $setManual = ['manual','manuales','guia','instructivo','documentacion','ayuda','tutorial'];
    $setWifi = ['wifi','wi fi','red','inalambrico','guest','internet','conexion','conectar'];
    $setBeneficios = ['beneficio','beneficios','prestaciones','cursos','capacitacion','minu','udemy','open','university'];
    $setDirectiva = ['directiva','politica','politicas','lineamientos','normativa'];

    foreach ($tokens as $t) {
        if (in_array($t, $setManual, true)) { $extra = array_merge($extra, $setManual); }
        if (in_array($t, $setWifi, true)) { $extra = array_merge($extra, $setWifi); }
        if (in_array($t, $setBeneficios, true)) { $extra = array_merge($extra, $setBeneficios); }
        if (in_array($t, $setDirectiva, true)) { $extra = array_merge($extra, $setDirectiva); }
    }
    // Asegurar al menos el término original
    if (empty($extra)) { $extra = $tokens; }
    $extra = array_values(array_unique($extra));

    if (!empty($extra)) {
        $likes = [];
        $params = [];
        foreach ($extra as $kw) {
            $likes[] = "(LOWER(palabra_clave) LIKE ? OR LOWER(recomendacion) LIKE ?)";
            $params[] = "%$kw%";
            $params[] = "%$kw%";
        }
        try {
            $sql = "SELECT recomendacion FROM $tabla WHERE " . implode(' OR ', $likes) . " LIMIT 1";
            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);
            $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
            return $resultado['recomendacion'] ?? null;
        } catch (Exception $e) {
            return null;
        }
    }

    return null;
}

// 4-5. Buscar en FAQs/Manual con apoyo de IA, priorizando por intención
// Orden de prioridad según intención detectada por IA
// 3.5. Antes: detectar ayuda/listados y responder directamente
if (!$respuesta) {
    if (detectarIntentAyuda($tokensNorm)) {
        $respuesta = '<strong>Puedo ayudarte con:</strong><br><br>' .
            '- Consultar <strong>empleados</strong> por nombre o área y mostrar sus datos de contacto.<br>' .
            '- Buscar en <strong>preguntas frecuentes</strong> para resolver dudas comunes.<br>' .
            '- Proporcionar <strong>manuales</strong> y guías (ej. WiFi, onboarding, GMM).<br>' .
            '- Listar <strong>áreas</strong>, <strong>niveles</strong>, <strong>localizaciones</strong> y <strong>tipos de trabajo</strong> registrados.<br><br>' .
            'Puedes preguntar: "¿qué manuales tienes?", "gente de finanzas", "beneficios disponibles", "directiva MX" o escribir libremente y yo interpretaré tu intención.';
    }
}

// 3.6. Detectar pedido de listado explícito en lenguaje natural
if (!$respuesta) {
    $entidadListado = detectarListadoEntidad($tokensNorm, $userMessage);
    if ($entidadListado) {
        $respListado = construirListadoDesdeBD($pdo, $entidadListado);
        if ($respListado) {
            $respuesta = $respListado;
        }
    }
}

if ($aiIntent === 'manuales') {
    $respuesta = buscarEnTablaSemantico($pdo, 'manual', $userMessage);
    if ($respuesta) {
        $respuesta = "Aquí tienes el manual de " . htmlspecialchars($userMessage) . ":<br><br>" . $respuesta;
    }
    if (!$respuesta) {
        $respuesta = buscarEnTablaSemantico($pdo, 'preguntas_frec', $userMessage);
    }
} else if ($aiIntent === 'beneficios' || $aiIntent === 'directiva') {
    $respuesta = buscarEnTablaSemantico($pdo, 'preguntas_frec', $userMessage);
    if (!$respuesta) {
        $respuesta = buscarEnTablaSemantico($pdo, 'manual', $userMessage);
        if ($respuesta) {
            $respuesta = "Aquí tienes el manual de " . htmlspecialchars($userMessage) . ":<br><br>" . $respuesta;
        }
    }
} else {
    // Orden clásico con semántica: FAQs -> Manual
    $respuesta = buscarEnTablaSemantico($pdo, 'preguntas_frec', $userMessage);
    if (!$respuesta) {
        $respuesta = buscarEnTablaSemantico($pdo, 'manual', $userMessage);
        if ($respuesta) {
            $respuesta = "Aquí tienes el manual de " . htmlspecialchars($userMessage) . ":<br><br>" . $respuesta;
        }
    }
}

// 6. Búsqueda en empleados con soporte de sinónimos/intents y listado por defecto
if (!$respuesta) {
    // Derivar término de búsqueda a partir de tokens normalizados (si existe alguno)
    $termino = null;
    if (!empty($tokensNorm)) {
        // Usar el primer token "significativo"
        $termino = $tokensNorm[0];
    }
    // Priorizar entidad detectada por IA si viene informada
    if (!empty($aiEntity)) {
        $termino = $aiEntity;
    }

    // Si el intent es empleados y no hay término significativo, listamos por defecto
    $listarPorDefecto = $intentaEmpleados && (empty($termino) || in_array($termino, ['empleado','empleados','trabajador','trabajadores','personal','gente','nomina','nómina','staff'], true));

    try {
        if ($listarPorDefecto) {
            $sql = "
                SELECT 
                    e.nombre, e.apellido, e.correo, e.telefono,
                    a.descripcion AS area, n.descripcion AS nivel,
                    l.descripcion AS localizacion, t.descripcion AS tipo_trabajo
                FROM empleado e
                LEFT JOIN area a ON e.id_area = a.id_area
                LEFT JOIN nivel n ON e.id_nivel = n.id_nivel
                LEFT JOIN localizacion l ON e.id_local = l.id_local
                LEFT JOIN tipo_trab t ON e.id_tip_trab = t.id_tip_trab
                LIMIT 5
            ";
            $stmt = $pdo->query($sql);
            $empleados = $stmt->fetchAll(PDO::FETCH_ASSOC);
        } else {
            // Buscar por nombre, apellido, nombre completo o área usando el texto original también
            $stmt = $pdo->prepare("
                SELECT 
                    e.nombre, 
                    e.apellido, 
                    e.correo,
                    e.telefono,
                    a.descripcion AS area, 
                    n.descripcion AS nivel, 
                    l.descripcion AS localizacion,
                    t.descripcion AS tipo_trabajo
                FROM empleado e
                LEFT JOIN area a ON e.id_area = a.id_area
                LEFT JOIN nivel n ON e.id_nivel = n.id_nivel
                LEFT JOIN localizacion l ON e.id_local = l.id_local
                LEFT JOIN tipo_trab t ON e.id_tip_trab = t.id_tip_trab
                WHERE 
                    e.nombre LIKE ? OR 
                    e.apellido LIKE ? OR 
                    CONCAT(e.nombre, ' ', e.apellido) LIKE ? OR
                    a.descripcion LIKE ?
                LIMIT 5
            ");
            $busqueda = "%" . ($termino ?: $userMessage) . "%";
            $stmt->execute([$busqueda, $busqueda, $busqueda, $busqueda]);
            $empleados = $stmt->fetchAll(PDO::FETCH_ASSOC);
        }
    } catch (Exception $e) {
        $empleados = [];
    }

    if ($empleados) {
        // Detectar si la búsqueda es por área
        $esBusquedaPorArea = false;
        foreach ($empleados as $emp) {
            if (stripos($emp['area'], $userMessage) !== false) {
                $esBusquedaPorArea = true;
                break;
            }
        }

        // Palabras clave que indican un "cargo"
        $palabrasCargo = [
            'director', 'leader', 'líder', 'engineer', 'ingeniero',
            'project', 'junior', 'senior', 'analista', 'coordinador',
            'manager', 'jefe'
        ];

        // Construir mensaje inicial según el tipo de búsqueda
        if ($esBusquedaPorArea) {
            $respuesta = "<strong>Estos empleados forman parte del área:</strong> " . htmlspecialchars($userMessage) . "<br><br>";
        } else {
            if (count($empleados) === 1) {
                $emp = $empleados[0];
                $area = strtolower($emp['area']);
                $cargoDetectado = null;

                // Verificar si el área contiene alguna palabra de cargo
                foreach ($palabrasCargo as $cargo) {
                    if (stripos($area, $cargo) !== false) {
                        $cargoDetectado = ucfirst($cargo);
                        break;
                    }
                }

                if ($cargoDetectado) {
                    $respuesta = "Encontré al <strong>{$cargoDetectado}</strong> <strong>" . htmlspecialchars($emp['nombre']) . " " . htmlspecialchars($emp['apellido']) . "</strong>:<br><br>";
                } else {
                    $respuesta = "Encontré al empleado <strong>" . htmlspecialchars($emp['nombre']) . " " . htmlspecialchars($emp['apellido']) . "</strong> de la empresa <strong>" . htmlspecialchars($emp['area']) . "</strong>:<br><br>";
                }
            } else {
                $respuesta = "<strong>Empleados relacionados con '" . htmlspecialchars($userMessage) . "':</strong><br><br>";
            }
        }

        // Mostrar lista de coincidencias
        foreach ($empleados as $emp) {
            $respuesta .= "- <strong>{$emp['nombre']} {$emp['apellido']}</strong> | Área: {$emp['area']} | Nivel: {$emp['nivel']} | Localización: {$emp['localizacion']} | Tipo: {$emp['tipo_trabajo']} | Correo: {$emp['correo']} | Tel: {$emp['telefono']}<br><br>";
        }
    }
}

// 7. Si aún no hay respuesta, intentar IA como fallback antes de registrar
if (!$respuesta) {
    $fallback = ai_fallback_answer($userMessage);
    if ($fallback) {
        $respuesta = htmlspecialchars($fallback);
    } else {
        $insert = $pdo->prepare("INSERT INTO preguntas_no_resueltas (pregunta) VALUES (?)");
        $insert->execute([$userMessage]);
        $respuesta = "Lo siento, no encontré información relacionada con tu mensaje. Tu consulta ha sido registrada para mejorar el sistema.";
    }
}

// 8. Responder en JSON
$reply = convertirLinksEnHtml($respuesta);
$reply = asegurarUtf8($reply);
header('Content-Type: application/json; charset=utf-8');
echo json_encode(['reply' => $reply], JSON_UNESCAPED_UNICODE);