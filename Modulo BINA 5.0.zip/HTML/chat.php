
<?php
header('Content-Type: application/json');

// 1. CONEXIÓN A LA BASE DE DATOS
$host = 'localhost';
$db = 'ia';
$user = 'root';
$pass = ''; // Por defecto en XAMPP
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (PDOException $e) {
    echo json_encode(['reply' => 'Error de conexión: ' . $e->getMessage()]);
    exit;
}

// 2. OBTENER EL MENSAJE DEL USUARIO
$userMessage = strtolower(trim($_POST['mensaje'] ?? ''));

// 3. RESPUESTAS SEGÚN MENSAJE
if ($userMessage === "mostrar empleados") {
    $stmt = $pdo->query("
        SELECT e.nombre, e.apellido, a.descripcion AS area, n.descripcion AS nivel 
        FROM empleado e 
        LEFT JOIN area a ON e.id_area = a.id_area 
        LEFT JOIN nivel n ON e.id_nivel = n.id_nivel 
        LIMIT 5
    ");
    $empleados = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $response = "Aquí tienes algunos empleados:\n";
    foreach ($empleados as $emp) {
        $response .= "- {$emp['nombre']} {$emp['apellido']} ({$emp['area']}, {$emp['nivel']})\n";
    }

} elseif (preg_match('/buscar (.+)/', $userMessage, $matches)) {
    $buscado = $matches[1];

    $stmt = $pdo->prepare("
        SELECT e.nombre, e.apellido, a.descripcion AS area, n.descripcion AS nivel 
        FROM empleado e 
        LEFT JOIN area a ON e.id_area = a.id_area 
        LEFT JOIN nivel n ON e.id_nivel = n.id_nivel 
        WHERE e.nombre LIKE ? OR e.apellido LIKE ?
    ");
    $stmt->execute(["%$buscado%", "%$buscado%"]);
    $resultados = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if ($resultados) {
        $response = "Resultados encontrados para \"$buscado\":\n";
        foreach ($resultados as $emp) {
            $response .= "- {$emp['nombre']} {$emp['apellido']} ({$emp['area']}, {$emp['nivel']})\n";
        }
    } else {
        $response = "No encontré empleados con el nombre o apellido \"$buscado\".";
    }

} else {
    $response = "Lo siento, no entendí tu mensaje. Puedes escribir:\n- \"mostrar empleados\"\n- \"buscar José\"\nO un nombre/apellido.";
}

// 4. DEVOLVER RESPUESTA EN JSON
echo json_encode(['reply' => $response]);
