<?php
header('Content-Type: application/json');

// 1. Conexión a la base de datos
$host = 'localhost';
$db = 'ia';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (PDOException $e) {
    echo json_encode(['reply' => 'Error de conexión: ' . $e->getMessage()]);
    exit;
}

function convertirLinksEnHtml($texto) {
    return preg_replace(
        '/(https?:\/\/[^\s]+)/',
        '<a href="$1" target="_blank">$1</a>',
        $texto
    );
}

// 2. Obtener el mensaje del usuario
$userMessage = strtolower(trim($_POST['mensaje'] ?? ''));

// 3. Buscar coincidencias en preguntas frecuentes y manual (ahora con SQL LIKE)
function buscarEnTablaPalabrasClave($pdo, $tabla, $mensaje) {
    $stmt = $pdo->prepare("SELECT recomendacion FROM $tabla WHERE LOWER(palabra_clave) LIKE ?");
    $stmt->execute(["%$mensaje%"]);
    $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
    return $resultado['recomendacion'] ?? null;
}

// 4. Buscar en preguntas_frec
$respuesta = buscarEnTablaPalabrasClave($pdo, 'preguntas_frec', $userMessage);

// 5. Buscar en manual si no encontró
if (!$respuesta) {
    $respuesta = buscarEnTablaPalabrasClave($pdo, 'manual', $userMessage);
    
    if ($respuesta) {
        $respuesta = "Aquí tienes el manual de " . htmlspecialchars($userMessage) . ":<br><br>" . $respuesta;
    }
}

// 6. Buscar en empleados por nombre/apellido/nombre completo o dar los 5 primeros empleados de cada area/junto con su cargo o empresa
if (!$respuesta) {
    // Buscar por nombre, apellido, nombre completo o área
    $stmt = $pdo->prepare("
        SELECT 
            e.nombre, 
            e.apellido, 
            e.correo,
            e.telefono,
            a.descripcion AS area, 
            n.descripcion AS nivel, 
            l.descripcion AS localizacion,
            t.descripcion AS tipo_trabajo
        FROM empleado e
        LEFT JOIN area a ON e.id_area = a.id_area
        LEFT JOIN nivel n ON e.id_nivel = n.id_nivel
        LEFT JOIN localizacion l ON e.id_local = l.id_local
        LEFT JOIN tipo_trab t ON e.id_tip_trab = t.id_tip_trab
        WHERE 
            e.nombre LIKE ? OR 
            e.apellido LIKE ? OR 
            CONCAT(e.nombre, ' ', e.apellido) LIKE ? OR
            a.descripcion LIKE ?
        LIMIT 5
    ");

    $busqueda = "%$userMessage%";
    $stmt->execute([$busqueda, $busqueda, $busqueda, $busqueda]);
    $empleados = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if ($empleados) {
        // Detectar si la búsqueda es por área
        $esBusquedaPorArea = false;
        foreach ($empleados as $emp) {
            if (stripos($emp['area'], $userMessage) !== false) {
                $esBusquedaPorArea = true;
                break;
            }
        }

        // Palabras clave que indican un "cargo"
        $palabrasCargo = [
            'director', 'leader', 'líder', 'engineer', 'ingeniero',
            'project', 'junior', 'senior', 'analista', 'coordinador',
            'manager', 'jefe'
        ];

        // Construir mensaje inicial según el tipo de búsqueda
        if ($esBusquedaPorArea) {
            $respuesta = "<strong>Estos empleados forman parte del área:</strong> " . htmlspecialchars($userMessage) . "<br><br>";
        } else {
            if (count($empleados) === 1) {
                $emp = $empleados[0];
                $area = strtolower($emp['area']);
                $cargoDetectado = null;

                // Verificar si el área contiene alguna palabra de cargo
                foreach ($palabrasCargo as $cargo) {
                    if (stripos($area, $cargo) !== false) {
                        $cargoDetectado = ucfirst($cargo);
                        break;
                    }
                }

                if ($cargoDetectado) {
                    $respuesta = "Encontré al <strong>{$cargoDetectado}</strong> <strong>" . htmlspecialchars($emp['nombre']) . " " . htmlspecialchars($emp['apellido']) . "</strong>:<br><br>";
                } else {
                    $respuesta = "Encontré al empleado <strong>" . htmlspecialchars($emp['nombre']) . " " . htmlspecialchars($emp['apellido']) . "</strong> de la empresa <strong>" . htmlspecialchars($emp['area']) . "</strong>:<br><br>";
                }
            } else {
                $respuesta = "<strong>Empleados relacionados con '" . htmlspecialchars($userMessage) . "':</strong><br><br>";
            }
        }

        // Mostrar lista de coincidencias
        foreach ($empleados as $emp) {
            $respuesta .= "- <strong>{$emp['nombre']} {$emp['apellido']}</strong> | Área: {$emp['area']} | Nivel: {$emp['nivel']} | Localización: {$emp['localizacion']} | Tipo: {$emp['tipo_trabajo']} | Correo: {$emp['correo']} | Tel: {$emp['telefono']}<br><br>";
        }
    }
}

// 7. Si aún no hay respuesta, registrar pregunta no resuelta
if (!$respuesta) {
    $insert = $pdo->prepare("INSERT INTO preguntas_no_resueltas (pregunta) VALUES (?)");
    $insert->execute([$userMessage]);

    $respuesta = "Lo siento, no encontré información relacionada con tu mensaje. Tu consulta ha sido registrada para mejorar el sistema.";
}

// 8. Responder en JSON
echo json_encode(['reply' => convertirLinksEnHtml($respuesta)]);