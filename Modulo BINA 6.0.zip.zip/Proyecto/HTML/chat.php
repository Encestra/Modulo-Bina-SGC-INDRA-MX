<?php
header('Content-Type: application/json');

// 1. Conexión a la base de datos
$host = 'localhost';
$db = 'ia';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (PDOException $e) {
    echo json_encode(['reply' => 'Error de conexión: ' . $e->getMessage()]);
    exit;
}

function convertirLinksEnHtml($texto) {
    return preg_replace(
        '/(https?:\/\/[^\s]+)/',
        '<a href="$1" target="_blank">$1</a>',
        $texto
    );
}

// 2. Obtener el mensaje del usuario
$userMessage = strtolower(trim($_POST['mensaje'] ?? ''));

// 3. Buscar coincidencias en preguntas frecuentes y manual (ahora con SQL LIKE)
function buscarEnTablaPalabrasClave($pdo, $tabla, $mensaje) {
    $stmt = $pdo->prepare("SELECT recomendacion FROM $tabla WHERE LOWER(palabra_clave) LIKE ?");
    $stmt->execute(["%$mensaje%"]);
    $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
    return $resultado['recomendacion'] ?? null;
}

// 4. Buscar en preguntas_frec
$respuesta = buscarEnTablaPalabrasClave($pdo, 'preguntas_frec', $userMessage);

// 5. Buscar en manual si no encontró
if (!$respuesta) {
    $respuesta = buscarEnTablaPalabrasClave($pdo, 'manual', $userMessage);
}

// 6. Buscar en empleados por nombre/apellido
if (!$respuesta) {
    $stmt = $pdo->prepare("
        SELECT 
            e.nombre, 
            e.apellido, 
            e.correo,
            e.telefono,
            a.descripcion AS area, 
            n.descripcion AS nivel, 
            l.descripcion AS localizacion,
            t.descripcion AS tipo_trabajo
        FROM empleado e
        LEFT JOIN area a ON e.id_area = a.id_area
        LEFT JOIN nivel n ON e.id_nivel = n.id_nivel
        LEFT JOIN localizacion l ON e.id_local = l.id_local
        LEFT JOIN tipo_trab t ON e.id_tip_trab = t.id_tip_trab
        WHERE 
            e.nombre LIKE ? OR 
            e.apellido LIKE ? OR 
            CONCAT(e.nombre, ' ', e.apellido) LIKE ? OR
            e.correo LIKE ? OR
            e.telefono LIKE ? OR
            a.descripcion LIKE ? OR
            n.descripcion LIKE ? OR
            l.descripcion LIKE ? OR
            t.descripcion LIKE ?
        LIMIT 5
    ");
    $busqueda = "%$userMessage%";
    $stmt->execute(array_fill(0, 9, $busqueda));
    $empleados = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if ($empleados) {
        $respuesta = "<strong>Empleados encontrados:</strong>\n\n";
        foreach ($empleados as $emp) {
            $respuesta .= "- {$emp['nombre']} {$emp['apellido']} | Área: {$emp['area']} | Nivel: {$emp['nivel']} | Ubicación: {$emp['localizacion']} | Tipo: {$emp['tipo_trabajo']} | Correo: {$emp['correo']} | Tel: {$emp['telefono']}\n\n";
        }
    }
}

// 7. Si aún no hay respuesta, registrar pregunta no resuelta
if (!$respuesta) {
    $insert = $pdo->prepare("INSERT INTO preguntas_no_resueltas (pregunta) VALUES (?)");
    $insert->execute([$userMessage]);

    $respuesta = "Lo siento, no encontré información relacionada con tu mensaje. Tu consulta ha sido registrada para mejorar el sistema.";
}

// 8. Responder en JSON
echo json_encode(['reply' => convertirLinksEnHtml($respuesta)]);