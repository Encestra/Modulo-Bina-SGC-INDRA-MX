document.addEventListener('DOMContentLoaded', () => {
    // Asegura que todo el HTML se haya cargado antes de intentar manipular los elementos.

    // ------------------ 1. REFERENCIAS DE ELEMENTOS HTML ------------------
    const chatToggleButton = document.getElementById('chatToggleButton');
    const closeChatButton = document.getElementById('closeChatButton');
    const refreshButton = document.getElementById('refreshButton');
    const chatWindow = document.getElementById('chatWindow');
    const chatBody = document.getElementById('chatBody');
    const messageInput = document.getElementById('messageInput');
    const sendButton = document.getElementById('sendButton');

    // ------------------ 2. ESTRUCTURAS DE MENSAJES (CONTENIDO) ------------------
    const initialMessages = [
        '<div class="message-bubble assistant"><p>¡Hola! Soy Bina, el asistente virtual de Indra. Puedes preguntarme dudas o enviar peticiones a Service Point sobre los ámbitos que domino.</p></div>',
        '<div class="message-bubble assistant"><p>Actualmente, algunas de mis funciones pueden no estar disponibles. Si durante nuestra conversación detectas algún problema o error, por favor, no dudes en enviar una petición a través de Service Point para informarlo.</p></div>',
        `<div class="message-bubble assistant">
            <p>Estos son los temas en los que te puedo atender actualmente, puedes orientarte a través de los botones o escribirme directamente tus dudas:</p>
            <div class="action-buttons-container" id="optionButtons">
                <button class="action-option-button" data-topic="dispositivos">Dispositivos y telefonía</button>
                <button class="action-option-button" data-topic="formacion">Formación</button>
                <button class="action-option-button" data-topic="permisos">Permisos retribuidos</button>
                <button class="action-option-button" data-topic="gastos">Gastos de empleado</button>
            </div>
        </div>`
    ];

    const createResponse = (topicName, shortMessage) => {
        return [
            `<div class="user-action-float selected-option"><button class="user-float-button">${topicName}</button></div>`,
            `<div class="action-buttons-container" id="optionButtons" style="margin-top: 15px;">
                <button class="action-option-button clicked" data-topic="dispositivos">Dispositivos y telefonía</button>
                <button class="action-option-button clicked" data-topic="formacion">Formación</button>
                <button class="action-option-button clicked" data-topic="permisos">Permisos retribuidos</button>
                <button class="action-option-button clicked" data-topic="gastos">Gastos de empleado</button>
            </div>`,
            `<div class="message-bubble assistant response-start"><p>${shortMessage}</p></div>`,
            '<div class="message-bubble assistant"><p>Puedes consultar más información a través de <strong>Service point</strong>, mediante el buscador o abriendo una consulta. También puedes abrir la consulta directamente desde aquí.</p></div>',
            '<div class="message-bubble assistant"><p>Si quieres hablar de otro tema, puedes preguntarme directamente o reiniciar el chat.</p></div>',
            `<div class="user-action-float"><button class="user-float-button">Enviar una petición sobre ${topicName.toLowerCase()} a Service point</button></div>`,
            `<div class="message-bubble assistant"><p>Escribe un resumen de tu petición sobre tu ${topicName.toLowerCase()}. Si quieres cancelar o modificar la operación, podrás hacerlo tras completar el formulario.</p></div>`
        ];
    };

    const responses = {
        formacion: createResponse("Formación", "En estos momentos estoy actualizando mis conocimientos sobre formación para adecuarlos a la nueva plataforma Open University."),
        dispositivos: createResponse("Dispositivos y telefonía", "El área de Dispositivos y telefonía se encarga de dar soporte a todo el hardware que usas en tu día a día, incluyendo móviles, portátiles y accesorios."),
        permisos: createResponse("Permisos retribuidos", "El tema de Permisos retribuidos abarca consultas sobre vacaciones, días libres, licencias por matrimonio, paternidad y otras ausencias legales."),
        gastos: createResponse("Gastos de empleado", "En este tema te puedo ayudar con dudas sobre el proceso de reporte de gastos, reportes de viaje y solicitudes de tickets y justificantes.")
    };

    // Listener para estrellas de valoración
    const stars = document.querySelectorAll('.star');

    stars.forEach((star, index) => {
        star.addEventListener('click', () => {
            const puntuacion = index + 1;

            // Opcional: cambiar visualmente las estrellas a llenas
            stars.forEach((s, i) => {
                s.textContent = i < puntuacion ? '★' : '☆';
            });

            // Enviar la puntuación al servidor
            fetch('valorar.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'valoracion=' + encodeURIComponent(puntuacion)
            })
            .then(response => response.json())
            .then(data => {
                alert(data.reply);
            })
            .catch(error => {
                alert('Error al enviar la valoración.');
                console.error(error);
            });
        });
    });

    // ------------------ 3. FUNCIONES DE LÓGICA DE CHAT ------------------

    function scrollToBottom() {
        chatBody.scrollTop = chatBody.scrollHeight;
    }

    function loadInitialChat() {
        chatBody.innerHTML = initialMessages.join('');
        scrollToBottom();

        const buttons = chatBody.querySelectorAll('.action-option-button');
        buttons.forEach(button => {
            button.addEventListener('click', handleOptionClick);
        });
    }

    function handleOptionClick(event) {
        const button = event.target;
        const topic = button.getAttribute('data-topic');
        const topicName = button.textContent;

        const allButtons = document.querySelectorAll('#optionButtons .action-option-button');
        allButtons.forEach(btn => {
            btn.classList.add('clicked');
            btn.removeEventListener('click', handleOptionClick);
        });

        chatBody.innerHTML += `<div class="user-action-float selected-option"><button class="user-float-button">${topicName}</button></div>`;

        if (responses[topic]) {
            const content = responses[topic].slice(1).join('');
            chatBody.innerHTML += content;
        } else {
            chatBody.innerHTML += '<div class="message-bubble assistant"><p>Lo siento, aún estoy aprendiendo sobre este tema. Por favor, reinicia el chat.</p></div>';
        }

        scrollToBottom();
    }

    async function handleSend() {
        const message = messageInput.value.trim();

        if (message !== "") {
            const userMsgDiv = document.createElement('div');
            userMsgDiv.className = 'message-bubble user-message';
            userMsgDiv.style.backgroundColor = '#0076a3';
            userMsgDiv.style.color = 'white';
            userMsgDiv.style.marginLeft = 'auto';
            userMsgDiv.style.textAlign = 'right';
            userMsgDiv.style.borderRadius = '8px 8px 0 8px';
            userMsgDiv.textContent = message;
            chatBody.appendChild(userMsgDiv);

            messageInput.value = '';
            scrollToBottom();

            try {
                const response = await fetch('chat.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: new URLSearchParams({ mensaje: message })
                });
                const data = await response.json();

                const botMsgDiv = document.createElement('div');
                botMsgDiv.className = 'message-bubble assistant';
                botMsgDiv.innerHTML = data.reply.replace(/\n/g, '<br>');
                chatBody.appendChild(botMsgDiv);

                scrollToBottom();
            } catch (error) {
                const botMsgDiv = document.createElement('div');
                botMsgDiv.className = 'message-bubble assistant';
                botMsgDiv.textContent = "Error al comunicarse con el servidor.";
                chatBody.appendChild(botMsgDiv);
                scrollToBottom();
            }
        }
    }

    function toggleChat() {
        const isVisible = window.getComputedStyle(chatWindow).display !== 'none';
        if (isVisible) {
            chatWindow.style.display = 'none';
            chatToggleButton.style.display = 'flex';
        } else {
            chatWindow.style.display = 'flex';
            chatToggleButton.style.display = 'none';
            loadInitialChat();
        }
    }

    // ------------------ 4. EVENT LISTENERS ------------------
    chatToggleButton.addEventListener('click', toggleChat);
    closeChatButton.addEventListener('click', toggleChat);
    refreshButton.addEventListener('click', loadInitialChat);
    sendButton.addEventListener('click', handleSend);
    messageInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            handleSend();
        }
    });
});

