document.addEventListener('DOMContentLoaded', () => {
    // Asegura que todo el HTML se haya cargado antes de intentar manipular los elementos.

    // ------------------ 1. REFERENCIAS DE ELEMENTOS HTML ------------------
    const chatToggleButton = document.getElementById('chatToggleButton');
    const closeChatButton = document.getElementById('closeChatButton');
    const refreshButton = document.getElementById('refreshButton');
    const chatWindow = document.getElementById('chatWindow');
    const chatBody = document.getElementById('chatBody');
    const messageInput = document.getElementById('messageInput');
    const sendButton = document.getElementById('sendButton');

    // ------------------ 2. ESTRUCTURAS DE MENSAJES (CONTENIDO) ------------------
    const initialMessages = [
        '<div class="message-bubble assistant"><p>¡Hola! Soy un modulo nuevo para Bina, el asistente virtual de Indra. Mi objetivo es responder tus dudas o registrarlas en el Service Point para guiarte dentro de Indra</p></div>',
        '<div class="message-bubble assistant"><p>Actualmente, algunas de mis funciones pueden no estar disponibles. Si durante nuestra conversación detectas algún problema o error, por favor, no dudes en enviar una petición a través de Service Point para informarlo.</p></div>',
        `<div class="message-bubble assistant">
            <p>Estos son los temas en los que te puedo atender actualmente, puedes orientarte a través de los botones o escribirme directamente tus dudas:</p>
            <div class="action-buttons-container" id="optionButtons">
                <button class="action-option-button" data-topic="Directiva">Directiva de Indra México</button>
                <button class="action-option-button" data-topic="Seguros">Seguros</button>
                <button class="action-option-button" data-topic="Beneficios">Beneficios para empleados</button>
                <button class="action-option-button" data-topic="Manuales">Manuales</button>
            </div>
        </div>`,
        `<div class="message-bubble assistant">
                <p>
                    ¿No es lo que estás buscando? Puedes intentar con las siguientes recomendaciones 
                    o escribir directamente tu duda y con gusto la atenderé:
                </p>
            <div>
                <p>
                Puedes darme el primer nombre de un empleado y yo lo buscaré dentro del directorio de Indra.
                </p>
                <p>
                Puedes escribir el área o departamento que buscas y te diré qué empleados pertenecen a esta.
                </p>
            </div>
        </div>`

    ];

    const createResponse = (topicName, shortMessage) => {
        return [
            `<div class="user-action-float selected-option"><button class="user-float-button">${topicName}</button></div>`,
            `<div class="message-bubble assistant response-start"><p>${shortMessage}</p></div>`,
            '<div class="message-bubble assistant"><p>Si quieres hacer una consulta sobre este tema y no esta en los sugeridos, puedes preguntarme directamente o reiniciar el chat.</p></div>',
        ];
    };

    const responses = {
        Directiva: createResponse("Directiva", "Escribe el area o empresa que deseas conocer y te mostrare sus empleados o dame el primer nombre de un empleado y te mostrare su información"),
        Seguros: createResponse("Seguros", "Como empleado de Indra gozas de varias polizas de seguros para tu protección, puedes gestionarlas en:<br><a href='https://axa.misbeneficiosaxa.com/' target='_blank'>Portal de Seguros Indra</a>"),
        Beneficios: createResponse("Beneficios", `Como empleado de Indra gozas de varios beneficios. Entre ellos: 
                                    <br> Minu: Un beneficio de tarjetas de despensa mensuales. Para saber más, ingresa a: 
                                    <br><a href='https://www.minu.mx/' target='_blank'>Beneficios MINU</a>
                                    <br><br> Udemy: Una plataforma de cursos en línea para ampliar tus conocimientos y prepararte. Para comenzar, ingresa a: 
                                    <br><a href='https://indra.udemy.com/organization/home/' target='_blank'>Udemy para empleados</a>
                                    <br><br> Open University: La plataforma de cursos internos de Indra, donde podrás conocer más sobre temas éticos y la empresa. Para saber más, ingresa a: 
                                    <br><a href='https://openuniversity.csod.com/LMS/catalog/Welcome.aspx?tab_page_id=-67&tab_id=-1' target='_blank'>Open University</a>`),
        Manuales: createResponse("Manuales", `En Indra contamos con varios manuales para la solucione de problemas comunues, puedes darme el tema del cual te gustaria consultar el manual y te lo proporcionare
                                    <br> Algunos manuales comunes son:
                                    <br> ¿Como conectarse a la Red Wifi de Indra Antara?:
                                    <br><a href='https://www.indraweb.net/languages/es-es/sistemasinformacion/herramientas/Herramientas/Guest%20Wifi/Guest%20Wifi%20Manual_ES.pdf' target='_blank'>Wifi Antara</a>
                                    <br><br> Conoce Indra, util para empleados nuevos:
                                    <br><a href='https://www.indraweb.net/indracommunity/chile/Documents/Presentaci%C3%B3n%20Corporativa%20Global%202017.pdf' target='_blank'>Presentación Corporativa</a>
                                    <br><br> Conoce la proteccion que Indra te brinda: 
                                    <br><a href='https://apps.indraweb.net/gestionseguros/tutoriales/TutorialSegurosES.pdf' target='_blank'>Manual de Seguros</a>`)
    };

    // Listener para estrellas de valoración
    const stars = document.querySelectorAll('.star');

    stars.forEach((star, index) => {
        star.addEventListener('click', () => {
            const puntuacion = index + 1;

            // Opcional: cambiar visualmente las estrellas a llenas
            stars.forEach((s, i) => {
                s.textContent = i < puntuacion ? '★' : '☆';
            });

            // Enviar la puntuación al servidor
            fetch('valorar.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'valoracion=' + encodeURIComponent(puntuacion)
            })
                .then(response => response.json())
                .then(data => {
                    alert(data.reply);
                })
                .catch(error => {
                    alert('Error al enviar la valoración.');
                    console.error(error);
                });
        });
    });

    // ------------------ 3. FUNCIONES DE LÓGICA DE CHAT ------------------

    function scrollToBottom() {
        chatBody.scrollTop = chatBody.scrollHeight;
    }

    function appendOptionButtonsBlock() {
        const block = document.createElement('div');
        block.className = 'action-buttons-container optionButtons';
        block.innerHTML = `
                <button class="action-option-button" data-topic="Directiva">Directiva de Indra México</button>
                <button class="action-option-button" data-topic="Seguros">Seguros</button>
                <button class="action-option-button" data-topic="Beneficios">Beneficios para empleados</button>
                <button class="action-option-button" data-topic="Manuales">Manuales</button>
        `;
        // Insertar como un nuevo bloque al final del chat
        const wrapper = document.createElement('div');
        wrapper.className = 'message-bubble assistant';
        wrapper.appendChild(block);
        chatBody.appendChild(wrapper);
    }

    function loadInitialChat() {
        chatBody.innerHTML = initialMessages.join('');
        scrollToBottom();

        const buttons = chatBody.querySelectorAll('.action-option-button');
        buttons.forEach(button => {
            button.addEventListener('click', handleOptionClick);
        });
    }

    function handleOptionClick(event) {
        const button = event.target;
        const topic = button.getAttribute('data-topic');
        const topicName = button.textContent;

        // Evitar reprocesar un botón ya usado
        if (button.classList.contains('clicked')) {
            return;
        }
        button.classList.add('clicked');

        chatBody.innerHTML += `<div class="user-action-float selected-option"><button class="user-float-button">${topicName}</button></div>`;

        if (responses[topic]) {
            const content = responses[topic].slice(1).join('');
            chatBody.innerHTML += content;
        } else {
            chatBody.innerHTML += '<div class="message-bubble assistant"><p>Lo siento, aún estoy aprendiendo sobre este tema. Por favor, reinicia el chat.</p></div>';
        }
        scrollToBottom();
    }

    async function handleSend() {
        const message = messageInput.value.trim();

        if (message !== "") {
            const userMsgDiv = document.createElement('div');
            userMsgDiv.className = 'message-bubble user-message';
            userMsgDiv.style.backgroundColor = '#0076a3';
            userMsgDiv.style.color = 'white';
            userMsgDiv.style.marginLeft = 'auto';
            userMsgDiv.style.textAlign = 'right';
            userMsgDiv.style.borderRadius = '8px 8px 0 8px';
            userMsgDiv.textContent = message;
            chatBody.appendChild(userMsgDiv);

            messageInput.value = '';
            scrollToBottom();

            try {
                const response = await fetch('chat.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: new URLSearchParams({ mensaje: message })
                });
                const data = await response.json();

                const botMsgDiv = document.createElement('div');
                botMsgDiv.className = 'message-bubble assistant';
                botMsgDiv.innerHTML = data.reply.replace(/\n/g, '<br>');
                chatBody.appendChild(botMsgDiv);

                appendOptionButtonsBlock();
                scrollToBottom();
            } catch (error) {
                const botMsgDiv = document.createElement('div');
                botMsgDiv.className = 'message-bubble assistant';
                botMsgDiv.textContent = "Error al comunicarse con el servidor.";
                chatBody.appendChild(botMsgDiv);
                appendOptionButtonsBlock();
                scrollToBottom();
            }
        }
    }

    function toggleChat() {
        const isVisible = window.getComputedStyle(chatWindow).display !== 'none';
        if (isVisible) {
            chatWindow.style.display = 'none';
            chatToggleButton.style.display = 'flex';
        } else {
            chatWindow.style.display = 'flex';
            chatToggleButton.style.display = 'none';
            loadInitialChat();
        }
    }

    // ------------------ 4. EVENT LISTENERS ------------------
    chatToggleButton.addEventListener('click', toggleChat);
    closeChatButton.addEventListener('click', toggleChat);
    refreshButton.addEventListener('click', loadInitialChat);
    sendButton.addEventListener('click', handleSend);
    messageInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            handleSend();
        }
    });
    // Delegación de eventos para cualquier bloque nuevo de botones
    chatBody.addEventListener('click', (e) => {
        const target = e.target;
        if (target && target.classList && target.classList.contains('action-option-button')) {
            handleOptionClick({ target });
        }
    });
});
