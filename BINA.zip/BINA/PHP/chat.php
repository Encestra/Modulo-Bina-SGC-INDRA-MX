<?php
header('Content-Type: application/json');

// -------------------------
// 1. Conexión a la base de datos
// -------------------------
$host = 'localhost';
$db   = 'ia';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (PDOException $e) {
    echo json_encode(['reply' => 'Error de conexión: ' . $e->getMessage()]);
    exit;
}

// -------------------------
// Función para convertir links a HTML
// -------------------------
function convertirLinksEnHtml($texto) {
    return preg_replace('/(https?:\/\/[^\s]+)/', '<a href="$1" target="_blank">$1</a>', $texto);
}

// -------------------------
// 2. Obtener mensaje del usuario
// -------------------------
$userMessage = trim($_POST['mensaje'] ?? '');
if ($userMessage === '') {
    echo json_encode(['reply' => 'Por favor envía un mensaje.']);
    exit;
}

// -------------------------
// 3. Función de búsqueda Full-Text en cualquier tabla
// -------------------------
function buscarFT($pdo, $tabla, $mensaje) {
    $stmt = $pdo->prepare("
        SELECT recomendacion,
               MATCH(palabra_clave) AGAINST(:msg IN NATURAL LANGUAGE MODE) AS score
        FROM $tabla
        WHERE MATCH(palabra_clave) AGAINST(:msg IN NATURAL LANGUAGE MODE)
        ORDER BY score DESC
        LIMIT 1
    ");
    $stmt->execute([':msg' => $mensaje]);
    $res = $stmt->fetch(PDO::FETCH_ASSOC);
    return $res['recomendacion'] ?? null;
}

// -------------------------
// 4. Detectar intent de empleados
// -------------------------
$palabrasEmpleados = [
    'empleado','empleados','trabajador','trabajadores','personal',
    'gente','staff','nomina','nómina','muestrame empleados','muéstrame empleados'
];
$esIntentEmpleados = false;
foreach ($palabrasEmpleados as $p) {
    if (stripos($userMessage, $p) !== false) {
        $esIntentEmpleados = true;
        break;
    }
}

// -------------------------
// 5. Búsqueda en FAQs y Manual
// -------------------------
$respuesta = buscarFT($pdo, 'preguntas_frec', $userMessage) ?: buscarFT($pdo, 'manual', $userMessage);

// -------------------------
// 6. Búsqueda en empleados
// -------------------------
if ($esIntentEmpleados || !$respuesta) {

    // Si es un intent genérico, listamos los primeros 5 empleados
    if ($esIntentEmpleados && preg_match('/muestrame|muéstrame|empleados/i', $userMessage)) {
        $stmt = $pdo->query("
            SELECT e.nombre, e.apellido, e.correo, e.telefono,
                   a.descripcion AS area, n.descripcion AS nivel,
                   l.descripcion AS localizacion, t.descripcion AS tipo_trabajo
            FROM empleado e
            LEFT JOIN area a ON e.id_area = a.id_area
            LEFT JOIN nivel n ON e.id_nivel = n.id_nivel
            LEFT JOIN localizacion l ON e.id_local = l.id_local
            LEFT JOIN tipo_trab t ON e.id_tip_trab = t.id_tip_trab
            LIMIT 5
        ");
        $empleados = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } else {
        // Búsqueda Full-Text por nombre, apellido o área
        $stmt = $pdo->prepare("
            SELECT e.nombre, e.apellido, e.correo, e.telefono,
                   a.descripcion AS area, n.descripcion AS nivel,
                   l.descripcion AS localizacion, t.descripcion AS tipo_trabajo,
                   MATCH(e.nombre, e.apellido) AGAINST(:msg IN NATURAL LANGUAGE MODE) AS score_emp,
                   MATCH(a.descripcion) AGAINST(:msg IN NATURAL LANGUAGE MODE) AS score_area
            FROM empleado e
            LEFT JOIN area a ON e.id_area = a.id_area
            LEFT JOIN nivel n ON e.id_nivel = n.id_nivel
            LEFT JOIN localizacion l ON e.id_local = l.id_local
            LEFT JOIN tipo_trab t ON e.id_tip_trab = t.id_tip_trab
            WHERE MATCH(e.nombre, e.apellido) AGAINST(:msg IN NATURAL LANGUAGE MODE)
               OR MATCH(a.descripcion) AGAINST(:msg IN NATURAL LANGUAGE MODE)
            ORDER BY GREATEST(score_emp, score_area) DESC
            LIMIT 5
        ");
        $stmt->execute([':msg' => $userMessage]);
        $empleados = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Construir respuesta si se encontraron empleados
    if (!empty($empleados)) {
        $respuesta = "<strong>Empleados relacionados con '" . htmlspecialchars($userMessage) . "':</strong><br><br>";
        foreach ($empleados as $emp) {
            $respuesta .= "- <strong>{$emp['nombre']} {$emp['apellido']}</strong> <br> Área: {$emp['area']} <br> Nivel: {$emp['nivel']} <br> Localización: {$emp['localizacion']} <br> Tipo: {$emp['tipo_trabajo']} <br> Correo: {$emp['correo']} <br> Tel: {$emp['telefono']}<br><br>";
        }
    }
}

// -------------------------
// 7. Fallback: si no hay respuesta, registrar pregunta no resuelta
// -------------------------
if (!$respuesta) {
    $pdo->prepare("INSERT INTO preguntas_no_resueltas (pregunta) VALUES (?)")->execute([$userMessage]);
    $respuesta = "Lo siento, no encontré información relacionada con tu mensaje. Tu consulta ha sido registrada.";
}

// -------------------------
// 8. Responder en JSON
// -------------------------
echo json_encode(['reply' => convertirLinksEnHtml($respuesta)]);
