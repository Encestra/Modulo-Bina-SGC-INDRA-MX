<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Asistente Virtual Bina - Indra</title>
    <link rel="stylesheet" href="../CSS/styles.css">
</head>

<body>


    <div class="chat-container">
        <button class="chat-toggle-button" id="chatToggleButton">
            <img src="../Resources/Icon_Bina.png" alt="Bina Asistente Virtual" class="assistant-icon-img">
        </button>


        <div class="chat-window-full" id="chatWindow">
            <header class="chat-header-bina">
                <div class="header-content">
                    <div class="User-login">
                        <h1 class="welcome-title">¡Hola, JOSHUA ABRAHAM!</h1>
                        <p class="status-message">Bina está disponible...</p>
                    </div>
                    <div class="Action-links">
                        <a href="https://indraistiprovisioning-dwp.onbmc.com/dwp/app/#/unavailable"
                            class="action-link">Solicitudes sobre Asistente virtual</a>
                        <a href="URL_DEL_LINK_2" class="action-link">+info</a>
                    </div>
                </div>

                <div class="assistant-image">
                    <span>

                    </span>
                </div>

                <div class="reload-and-close">
                    <div>
                        <button class="action-button close-button" id="closeChatButton">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div>
                        <button class="action-button refresh-button" id="refreshButton">
                            <span class="refresh-icon">↻</span>
                        </button>
                    </div>
                </div>
            </header>

            <div class="header-actions">
                <span id="Val">Valórame</span>
                <span class="star">☆</span>
                <span class="star">☆</span>
                <span class="star">☆</span>
                <span class="star">☆</span>
                <span class="star">☆</span>
            </div>

            <main class="chat-body-bina" id="chatBody">
            </main>

            <footer class="chat-footer-bina">
                <input type="text" id="messageInput" placeholder="Escribe aquí tu mensaje..."
                    aria-label="Escribe tu mensaje">
                <button class="send-button" id="sendButton" aria-label="Enviar mensaje">
                    <span class="send-icon">➤</span>
                </button>
            </footer>
        </div>
    </div>

    <script src="../JS/script.js"></script>
</body>

</html>