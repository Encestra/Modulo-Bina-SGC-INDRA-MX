<?php
header('Content-Type: application/json');

// 1. Conexión a la base de datos
$host = 'localhost';
$db = 'ia';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (PDOException $e) {
    echo json_encode(['reply' => 'Error de conexión: ' . $e->getMessage()]);
    exit;
}

function convertirLinksEnHtml($texto) {
    return preg_replace(
        '/(https?:\/\/[^\s]+)/',
        '<a href="$1" target="_blank">$1</a>',
        $texto
    );
}

// Normaliza texto en español: minúsculas, quita acentos y stopwords simples
function normalizarTexto($texto) {
    $t = mb_strtolower(trim($texto), 'UTF-8');
    // Quitar acentos
    $t = iconv('UTF-8', 'ASCII//TRANSLIT', $t);
    if ($t === false) { $t = mb_strtolower(trim($texto), 'UTF-8'); }
    // Eliminar caracteres no alfanuméricos básicos
    $t = preg_replace('/[^a-z0-9\s]/', ' ', $t);
    $t = preg_replace('/\s+/', ' ', $t);
    // Stopwords muy básicas orientadas a preguntas
    $stop = [
        'de','la','el','los','las','un','una','unos','unas','lo','al','del',
        'que','cual','cuales','cuáles','cuales','cual','son','es','por','para',
        'quien','quienes','quién','quiénes','dime','di','muestrame','muestráme',
        'muestra','mostrar','ver','lista','listar','enseñame','ensename','me',
        'los','las','a','en','con','sobre','de','un','una','como','cómo','cuanto','cuánto'
    ];
    $tokens = array_values(array_filter(explode(' ', $t), function($w) use ($stop) {
        return $w !== '' && !in_array($w, $stop, true);
    }));
    return $tokens;
}

// Detecta intent de empleados por sinónimos comunes
function detectarIntentEmpleados($textoNormalizadoSinAcentos) {
    // Trabajamos sobre el string completo para facilitar coincidencias
    $s = is_array($textoNormalizadoSinAcentos)
        ? implode(' ', $textoNormalizadoSinAcentos)
        : $textoNormalizadoSinAcentos;
    $sinonimos = [
        'empleado','empleados','trabajador','trabajadores','personal','gente','nomina','nómina','staff'
    ];
    foreach ($sinonimos as $pal) {
        if (strpos($s, $pal) !== false) return true;
    }
    // Patrones tipo "quien es" implican entidad persona
    if (preg_match('/\bquien\s+es\b/', $s)) {
        return true;
    }
    return false;
}

// 2. Obtener el mensaje del usuario
$userMessage = strtolower(trim($_POST['mensaje'] ?? ''));
$tokensNorm = normalizarTexto($userMessage);
$intentaEmpleados = detectarIntentEmpleados($tokensNorm);

// 2.1. Integración con OpenAI (intents y entidad)
require_once __DIR__ . '/ai_client.php';
$aiIntent = null;
$aiEntity = '';
$aiClassification = ai_classify_intent($userMessage);
if (is_array($aiClassification)) {
    $aiIntent = $aiClassification['intent'] ?? null;
    $aiEntity = $aiClassification['entity'] ?? '';
    if ($aiIntent === 'empleados') {
        $intentaEmpleados = true; // refuerza el intent detectado manualmente
    }
}

// 3. Buscar coincidencias en preguntas frecuentes y manual (ahora con SQL LIKE)
function buscarEnTablaPalabrasClave($pdo, $tabla, $mensaje) {
    // Busca tanto en palabra_clave como en recomendacion
    $stmt = $pdo->prepare("SELECT recomendacion FROM $tabla WHERE LOWER(palabra_clave) LIKE ? OR LOWER(recomendacion) LIKE ? LIMIT 1");
    $stmt->execute(["%$mensaje%", "%$mensaje%"]); 
    $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
    return $resultado['recomendacion'] ?? null;
}

// Búsqueda semántica simple usando IA para expandir palabras clave
function buscarEnTablaSemantico($pdo, $tabla, $mensaje) {
    // Primero, intento directo (por compatibilidad)
    $directa = buscarEnTablaPalabrasClave($pdo, $tabla, $mensaje);
    if ($directa) return $directa;

    // Luego, si hay IA configurada, expandimos palabras clave
    if (function_exists('ai_expand_keywords')) {
        $keywords = ai_expand_keywords($mensaje);
        if (is_array($keywords) && !empty($keywords)) {
            // Construir consulta dinámica con ORs sobre palabra_clave y recomendacion
            $likes = [];
            $params = [];
            foreach ($keywords as $kw) {
                $likes[] = "(LOWER(palabra_clave) LIKE ? OR LOWER(recomendacion) LIKE ?)";
                $params[] = "%$kw%";
                $params[] = "%$kw%";
            }
            $sql = "SELECT recomendacion FROM $tabla WHERE " . implode(' OR ', $likes) . " LIMIT 1";
            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);
            $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
            return $resultado['recomendacion'] ?? null;
        }
    }
    
    // Sin IA: expansión local de palabras clave a partir de heurísticas
    $tokens = normalizarTexto($mensaje);
    $extra = [];
    $setManual = ['manual','manuales','guia','instructivo','documentacion','ayuda','tutorial'];
    $setWifi = ['wifi','wi fi','red','inalambrico','guest','internet','conexion','conectar'];
    $setBeneficios = ['beneficio','beneficios','prestaciones','cursos','capacitacion','minu','udemy','open','university'];
    $setDirectiva = ['directiva','politica','politicas','lineamientos','normativa'];

    foreach ($tokens as $t) {
        if (in_array($t, $setManual, true)) { $extra = array_merge($extra, $setManual); }
        if (in_array($t, $setWifi, true)) { $extra = array_merge($extra, $setWifi); }
        if (in_array($t, $setBeneficios, true)) { $extra = array_merge($extra, $setBeneficios); }
        if (in_array($t, $setDirectiva, true)) { $extra = array_merge($extra, $setDirectiva); }
    }
    // Asegurar al menos el término original
    if (empty($extra)) { $extra = $tokens; }
    $extra = array_values(array_unique($extra));

    if (!empty($extra)) {
        $likes = [];
        $params = [];
        foreach ($extra as $kw) {
            $likes[] = "(LOWER(palabra_clave) LIKE ? OR LOWER(recomendacion) LIKE ?)";
            $params[] = "%$kw%";
            $params[] = "%$kw%";
        }
        $sql = "SELECT recomendacion FROM $tabla WHERE " . implode(' OR ', $likes) . " LIMIT 1";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
        return $resultado['recomendacion'] ?? null;
    }

    return null;
}

// 4-5. Buscar en FAQs/Manual con apoyo de IA, priorizando por intención
// Orden de prioridad según intención detectada por IA
if ($aiIntent === 'manuales') {
    $respuesta = buscarEnTablaSemantico($pdo, 'manual', $userMessage);
    if ($respuesta) {
        $respuesta = "Aquí tienes el manual de " . htmlspecialchars($userMessage) . ":<br><br>" . $respuesta;
    }
    if (!$respuesta) {
        $respuesta = buscarEnTablaSemantico($pdo, 'preguntas_frec', $userMessage);
    }
} else if ($aiIntent === 'beneficios' || $aiIntent === 'directiva') {
    $respuesta = buscarEnTablaSemantico($pdo, 'preguntas_frec', $userMessage);
    if (!$respuesta) {
        $respuesta = buscarEnTablaSemantico($pdo, 'manual', $userMessage);
        if ($respuesta) {
            $respuesta = "Aquí tienes el manual de " . htmlspecialchars($userMessage) . ":<br><br>" . $respuesta;
        }
    }
} else {
    // Orden clásico con semántica: FAQs -> Manual
    $respuesta = buscarEnTablaSemantico($pdo, 'preguntas_frec', $userMessage);
    if (!$respuesta) {
        $respuesta = buscarEnTablaSemantico($pdo, 'manual', $userMessage);
        if ($respuesta) {
            $respuesta = "Aquí tienes el manual de " . htmlspecialchars($userMessage) . ":<br><br>" . $respuesta;
        }
    }
}

// 6. Búsqueda en empleados con soporte de sinónimos/intents y listado por defecto
if (!$respuesta) {
    // Derivar término de búsqueda a partir de tokens normalizados (si existe alguno)
    $termino = null;
    if (!empty($tokensNorm)) {
        // Usar el primer token "significativo"
        $termino = $tokensNorm[0];
    }
    // Priorizar entidad detectada por IA si viene informada
    if (!empty($aiEntity)) {
        $termino = $aiEntity;
    }

    // Si el intent es empleados y no hay término significativo, listamos por defecto
    $listarPorDefecto = $intentaEmpleados && (empty($termino) || in_array($termino, ['empleado','empleados','trabajador','trabajadores','personal','gente','nomina','nómina','staff'], true));

    if ($listarPorDefecto) {
        $sql = "
            SELECT 
                e.nombre, e.apellido, e.correo, e.telefono,
                a.descripcion AS area, n.descripcion AS nivel,
                l.descripcion AS localizacion, t.descripcion AS tipo_trabajo
            FROM empleado e
            LEFT JOIN area a ON e.id_area = a.id_area
            LEFT JOIN nivel n ON e.id_nivel = n.id_nivel
            LEFT JOIN localizacion l ON e.id_local = l.id_local
            LEFT JOIN tipo_trab t ON e.id_tip_trab = t.id_tip_trab
            LIMIT 5
        ";
        $stmt = $pdo->query($sql);
        $empleados = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } else {
        // Buscar por nombre, apellido, nombre completo o área usando el texto original también
        $stmt = $pdo->prepare("
            SELECT 
                e.nombre, 
                e.apellido, 
                e.correo,
                e.telefono,
                a.descripcion AS area, 
                n.descripcion AS nivel, 
                l.descripcion AS localizacion,
                t.descripcion AS tipo_trabajo
            FROM empleado e
            LEFT JOIN area a ON e.id_area = a.id_area
            LEFT JOIN nivel n ON e.id_nivel = n.id_nivel
            LEFT JOIN localizacion l ON e.id_local = l.id_local
            LEFT JOIN tipo_trab t ON e.id_tip_trab = t.id_tip_trab
            WHERE 
                e.nombre LIKE ? OR 
                e.apellido LIKE ? OR 
                CONCAT(e.nombre, ' ', e.apellido) LIKE ? OR
                a.descripcion LIKE ?
            LIMIT 5
        ");
        $busqueda = "%" . ($termino ?: $userMessage) . "%";
        $stmt->execute([$busqueda, $busqueda, $busqueda, $busqueda]);
        $empleados = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    if ($empleados) {
        // Detectar si la búsqueda es por área
        $esBusquedaPorArea = false;
        foreach ($empleados as $emp) {
            if (stripos($emp['area'], $userMessage) !== false) {
                $esBusquedaPorArea = true;
                break;
            }
        }

        // Palabras clave que indican un "cargo"
        $palabrasCargo = [
            'director', 'leader', 'líder', 'engineer', 'ingeniero',
            'project', 'junior', 'senior', 'analista', 'coordinador',
            'manager', 'jefe'
        ];

        // Construir mensaje inicial según el tipo de búsqueda
        if ($esBusquedaPorArea) {
            $respuesta = "<strong>Estos empleados forman parte del área:</strong> " . htmlspecialchars($userMessage) . "<br><br>";
        } else {
            if (count($empleados) === 1) {
                $emp = $empleados[0];
                $area = strtolower($emp['area']);
                $cargoDetectado = null;

                // Verificar si el área contiene alguna palabra de cargo
                foreach ($palabrasCargo as $cargo) {
                    if (stripos($area, $cargo) !== false) {
                        $cargoDetectado = ucfirst($cargo);
                        break;
                    }
                }

                if ($cargoDetectado) {
                    $respuesta = "Encontré al <strong>{$cargoDetectado}</strong> <strong>" . htmlspecialchars($emp['nombre']) . " " . htmlspecialchars($emp['apellido']) . "</strong>:<br><br>";
                } else {
                    $respuesta = "Encontré al empleado <strong>" . htmlspecialchars($emp['nombre']) . " " . htmlspecialchars($emp['apellido']) . "</strong> de la empresa <strong>" . htmlspecialchars($emp['area']) . "</strong>:<br><br>";
                }
            } else {
                $respuesta = "<strong>Empleados relacionados con '" . htmlspecialchars($userMessage) . "':</strong><br><br>";
            }
        }

        // Mostrar lista de coincidencias
        foreach ($empleados as $emp) {
            $respuesta .= "- <strong>{$emp['nombre']} {$emp['apellido']}</strong> | Área: {$emp['area']} | Nivel: {$emp['nivel']} | Localización: {$emp['localizacion']} | Tipo: {$emp['tipo_trabajo']} | Correo: {$emp['correo']} | Tel: {$emp['telefono']}<br><br>";
        }
    }
}

// 7. Si aún no hay respuesta, intentar IA como fallback antes de registrar
if (!$respuesta) {
    $fallback = ai_fallback_answer($userMessage);
    if ($fallback) {
        $respuesta = htmlspecialchars($fallback);
    } else {
        $insert = $pdo->prepare("INSERT INTO preguntas_no_resueltas (pregunta) VALUES (?)");
        $insert->execute([$userMessage]);
        $respuesta = "Lo siento, no encontré información relacionada con tu mensaje. Tu consulta ha sido registrada para mejorar el sistema.";
    }
}

// 8. Responder en JSON
echo json_encode(['reply' => convertirLinksEnHtml($respuesta)]);