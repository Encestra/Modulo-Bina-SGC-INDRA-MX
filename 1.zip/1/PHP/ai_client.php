<?php
// Cliente ligero para OpenAI usando cURL sin dependencias externas
// Configuración por variables de entorno:
//   OPENAI_API_KEY (obligatoria para habilitar)
//   OPENAI_MODEL   (opcional, por defecto: gpt-4o-mini o gpt-3.5-turbo)

function openai_is_configured(): bool {
    $key = getenv('OPENAI_API_KEY');
    return !empty($key);
}

function openai_chat_simple(string $system, string $user, ?string $model = null, float $temperature = 0.2, int $timeout = 10): ?string {
    $apiKey = getenv('OPENAI_API_KEY');
    if (empty($apiKey)) {
        return null;
    }
    $model = $model ?: (getenv('OPENAI_MODEL') ?: 'gpt-4o-mini');

    $url = 'https://api.openai.com/v1/chat/completions';
    $payload = [
        'model' => $model,
        'messages' => [
            ['role' => 'system', 'content' => $system],
            ['role' => 'user', 'content' => $user],
        ],
        'temperature' => $temperature,
        'max_tokens' => 512,
    ];

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        'Authorization: Bearer ' . $apiKey,
    ]);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
    curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);

    $response = curl_exec($ch);
    if ($response === false) {
        curl_close($ch);
        return null;
    }

    $status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($status < 200 || $status >= 300) {
        return null;
    }

    $data = json_decode($response, true);
    if (!isset($data['choices'][0]['message']['content'])) {
        return null;
    }

    return trim($data['choices'][0]['message']['content']);
}

// Clasificador de intención y extracción de entidad en español
// Devuelve array: ['intent' => 'empleados|beneficios|manuales|directiva|otro', 'entity' => 'valor o ""']
function ai_classify_intent(string $userMessage): ?array {
    if (!openai_is_configured()) return null;

    $system = 'Eres un clasificador de intenciones para un asistente interno de Indra. '
        . 'Responde SOLO en JSON estricto sin texto adicional. Intenciones válidas: '
        . '"empleados", "beneficios", "manuales", "directiva", "otro". '
        . 'Extrae una entidad principal si aplica: nombre de persona o área; si no hay, pon cadena vacía. '
        . 'Campos requeridos: intent, entity.';

    $user = "Clasifica la intención y entidad del siguiente mensaje en español. Mensaje: " . $userMessage
        . "\nResponde en el formato JSON: {\"intent\": \"...\", \"entity\": \"...\"}";

    $out = openai_chat_simple($system, $user, null, 0.0, 8);
    if (!$out) return null;

    // Intentar decodificar JSON embebido
    $jsonStart = strpos($out, '{');
    $jsonEnd = strrpos($out, '}');
    if ($jsonStart === false || $jsonEnd === false || $jsonEnd < $jsonStart) {
        return null;
    }
    $json = substr($out, $jsonStart, $jsonEnd - $jsonStart + 1);
    $parsed = json_decode($json, true);
    if (!is_array($parsed) || !isset($parsed['intent'])) return null;

    $parsed['entity'] = isset($parsed['entity']) ? trim((string)$parsed['entity']) : '';
    return $parsed;
}

// Fallback generativo simple cuando no hay respuesta en BD
function ai_fallback_answer(string $userMessage): ?string {
    if (!openai_is_configured()) return null;

    $system = 'Eres Bina, asistente interno de Indra. Da respuestas concisas y útiles en español. '
        . 'No inventes datos personales ni correos; si no puedes acceder a datos, explica brevemente cómo encontrarlos. '
        . 'Cuando el usuario pida empleados por área o nombre, guía para usar el directorio interno.';
    $user = $userMessage;
    return openai_chat_simple($system, $user, null, 0.3, 10);
}

// Expande un mensaje en una lista corta de palabras clave en español (3-6 términos)
// Devuelve array de strings en minúsculas sin signos
function ai_expand_keywords(string $userMessage): ?array {
    if (!openai_is_configured()) return null;
    $system = 'Eres un asistente que extrae de 3 a 6 palabras clave relevantes en español para buscar en una base de conocimiento. '
        . 'Devuelve SOLO una lista separada por comas, en minúsculas y sin tildes ni signos.';
    $user = 'Extrae palabras clave del siguiente mensaje: ' . $userMessage;
    $out = openai_chat_simple($system, $user, null, 0.0, 8);
    if (!$out) return null;
    // Normalizar y partir por comas
    $out = strtolower($out);
    $out = iconv('UTF-8', 'ASCII//TRANSLIT', $out);
    $parts = array_map('trim', explode(',', $out));
    $parts = array_values(array_filter($parts, function($p){ return $p !== ''; }));
    if (empty($parts)) return null;
    return $parts;
}
