<!-- Incluye Bootstrap 5 desde CDN (CSS y JS) -->
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Ejemplo de la BD</title>
  <!-- CSS de Bootstrap -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
  <?php include 'DB/conexion.php'; ?>
  <div class="container">
    <h1 class="text-primary">Ejemplo</h1>
    <p class="lead">Esto es un ejemplo de la tabla empleado</p>
  <?php
  $sql = "SELECT * FROM empleado";
$resultado = $conn->query($sql);

// Verificar si hay resultados
if ($resultado && $resultado->num_rows > 0) {
    echo "<table class='table'>";
    echo "<tr><th>Id</th><th>Nombre</th><th>Apellido</th><th>Teléfono</th><th>Correo</th></tr>";

    // Mostrar los datos
    while ($fila = $resultado->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $fila['id_emp'] . "</td>";
        echo "<td>" . $fila['nombre'] . "</td>";
        echo "<td>" . $fila['apellido'] . "</td>";
        echo "<td>" . $fila['telefono'] . "</td>";
        echo "<td>" . $fila['correo'] . "</td>";
        echo "</tr>";
    }

    echo "</table>";
} else {
    echo "No se encontraron resultados.";
}

// Cerrar conexión 
$conn->close();
?>


 </div>
  <!-- JS de Bootstrap (opcional si usas componentes interactivos) -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>